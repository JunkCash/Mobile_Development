package com.capstone.junkcash.ui.screen.profile

class ProfileViewModel {
}