package com.capstone.junkcash.ui.screen.auth

class AuthActivity {
}