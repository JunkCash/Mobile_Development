package com.capstone.junkcash.ui.screen.scan;

public class ScanViewModel {
}
