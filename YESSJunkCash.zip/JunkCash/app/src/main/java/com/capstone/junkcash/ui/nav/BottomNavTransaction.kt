package com.capstone.junkcash.ui.nav

enum class BottomNavTransaction {
    Diproses,
    Selesai,
    Dibatalkan
}