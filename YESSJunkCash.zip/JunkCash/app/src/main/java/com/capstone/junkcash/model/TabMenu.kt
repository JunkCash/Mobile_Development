package com.capstone.junkcash.model

data class TabMenu(
    val id: Int,
    val title: String,
    val latitude: Double,
    val longtitude: Double
)