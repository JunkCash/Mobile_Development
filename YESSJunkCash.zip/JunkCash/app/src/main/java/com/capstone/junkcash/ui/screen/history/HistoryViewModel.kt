package com.capstone.junkcash.ui.screen.history

class HistoryViewModel {
}