package com.capstone.junkcash.ui.screen.login

class LoginViewModel {
}