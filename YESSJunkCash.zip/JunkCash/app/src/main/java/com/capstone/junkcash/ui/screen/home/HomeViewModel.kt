package com.capstone.junkcash.ui.screen.home

class HomeViewModel {
}