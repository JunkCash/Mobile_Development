package com.capstone.junkcash.ui.screen.welcome

class WelcomeViewModel {
}