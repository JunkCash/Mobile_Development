package com.capstone.junkcash.data.network.retrofit

import com.capstone.junkcash.data.network.request.OrderTransactionRequest
import com.capstone.junkcash.data.network.response.OrderTransactionResponse
import com.capstone.junkcash.data.network.response.Orders
import com.capstone.junkcash.data.network.response.OrdersResponse
import com.capstone.junkcash.model.User
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("orders")
    suspend fun getAllOrders(): Response<OrdersResponse>

    @GET("orders/email/{email}")
    suspend fun getUserOrders(
        @Path("email") email: String
    ): Response<OrdersResponse>

    @POST("orders")
    suspend fun createOrder(@Body request: OrderTransactionRequest): Response<OrderTransactionResponse>


}