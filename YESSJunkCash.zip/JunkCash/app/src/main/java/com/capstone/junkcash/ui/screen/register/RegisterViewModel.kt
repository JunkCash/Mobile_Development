package com.capstone.junkcash.ui.screen.register

class RegisterViewModel {
}