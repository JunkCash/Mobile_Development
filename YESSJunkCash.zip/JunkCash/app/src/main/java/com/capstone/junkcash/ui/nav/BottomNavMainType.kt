package com.capstone.junkcash.ui.nav

enum class BottomNavMainType {
    HOME,
    SCAN,
    TRANSACTION
}