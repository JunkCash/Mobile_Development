package com.capstone.junkcash.ui.components

class SplashScreenComponent {
}