package com.capstone.junkcash.ui.nav

class Screen {
}